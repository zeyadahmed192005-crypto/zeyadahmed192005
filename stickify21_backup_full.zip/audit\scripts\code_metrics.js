import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, '../../');

function getFiles(dir, exts = ['.js', '.html']) {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const file of list) {
    if (file === 'node_modules' || file === '.git' || file === 'audit' || file === 'test-results') continue;
    const full = path.join(dir, file);
    const stat = fs.statSync(full);
    if (stat.isDirectory()) {
      results = results.concat(getFiles(full, exts));
    } else if (exts.includes(path.extname(file))) {
      results.push(full);
    }
  }
  return results;
}

const allFiles = getFiles(repoRoot);
const largeFiles = [];

for (const file of allFiles) {
  const content = fs.readFileSync(file, 'utf-8');
  const lines = content.split('\n').length;
  const rel = path.relative(repoRoot, file);
  if (lines > 500) {
    largeFiles.push({ file: rel, lines });
  }
}

console.log('=== FILES OVER 500 LINES ===');
largeFiles.sort((a, b) => b.lines - a.lines);
console.log(JSON.stringify(largeFiles, null, 2));

fs.writeFileSync(
  path.join(__dirname, '../logs/code_metrics.json'),
  JSON.stringify({ largeFiles }, null, 2)
);
