import { chromium } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, '../../');

async function runAuditAdminAndSeo() {
  console.log('=== STARTING AUDIT FOR SECTIONS H & I ===');
  const report = { H: {}, I: {} };
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  const page = await browser.newPage();

  // H1: Recompute KPI math independently
  await page.goto('http://127.0.0.1:3000/admin.html');
  const lock = await page.$('#admin-lock-screen:not(.hidden)');
  if (lock) {
    await page.fill('#admin-pin-input', '2121');
    await page.click('#admin-login-btn');
    await page.waitForTimeout(500);
  }

  const kpiAudit = await page.evaluate(() => {
    const rawOrders = JSON.parse(localStorage.getItem('stickify21_orders') || '[]');
    const domRev = document.getElementById('stat-total-revenue')?.textContent?.replace(/[^\d]/g, '');
    const domCount = document.getElementById('stat-total-orders')?.textContent?.trim();
    const domAwaiting = document.getElementById('stat-awaiting-orders')?.textContent?.trim();
    const domShipped = document.getElementById('stat-shipped-orders')?.textContent?.trim();

    // Independent calc
    const indRev = rawOrders.reduce((sum, o) => sum + (parseInt(o.total, 10) || 0), 0);
    const indCount = rawOrders.length;
    const indAwaiting = rawOrders.filter(o => ['awaiting_confirmation', 'pending'].includes(o.status)).length;
    const indShipped = rawOrders.filter(o => ['shipped', 'completed'].includes(o.status)).length;

    return {
      rawCount: indCount,
      revenueMatch: Number(domRev || 0) === indRev,
      ordersMatch: Number(domCount || 0) === indCount,
      awaitingMatch: Number(domAwaiting || 0) === indAwaiting,
      shippedMatch: Number(domShipped || 0) === indShipped,
      domValues: { rev: domRev, count: domCount, awaiting: domAwaiting, shipped: domShipped },
      indValues: { rev: indRev, count: indCount, awaiting: indAwaiting, shipped: indShipped }
    };
  });

  report.H.H1 = {
    status: (kpiAudit.revenueMatch && kpiAudit.ordersMatch) ? 'PASS' : 'FAIL',
    evidence: kpiAudit
  };

  // H2: Stress Test on 500 Generated Orders
  console.log('Testing H2: Admin performance with 500 generated orders...');
  const perfResult = await page.evaluate(async () => {
    const orders = [];
    const now = Date.now();
    for (let i = 1; i <= 500; i++) {
      orders.push({
        id: `S21-261117-${String(i).padStart(4, '0')}`,
        date: new Date(now - i * 3600000).toISOString(),
        customer: {
          name: `عميل تيست ${i}`,
          phone: `010${String(10000000 + i).slice(0, 8)}`,
          city: i % 2 === 0 ? 'القاهرة' : 'الإسكندرية',
          address: `عنوان رقم ${i}`
        },
        items: [{ id: 1, nameAr: 'استيكر', price: 35, size: 'medium', qty: 1 }],
        subtotal: 35,
        shippingCost: 45,
        total: 80,
        status: i % 3 === 0 ? 'shipped' : (i % 2 === 0 ? 'confirmed' : 'awaiting_confirmation')
      });
    }

    localStorage.setItem('stickify21_orders', JSON.stringify(orders));
    const t0 = performance.now();
    // Trigger render
    if (window.renderOrders) window.renderOrders();
    const t1 = performance.now();

    // Test search filter
    const searchInput = document.getElementById('order-search-input');
    let tSearch = 0;
    if (searchInput) {
      searchInput.value = 'عميل تيست 250';
      const ts0 = performance.now();
      if (window.handleOrderFilterChange) window.handleOrderFilterChange();
      const ts1 = performance.now();
      tSearch = ts1 - ts0;
    }

    return {
      totalOrders: 500,
      renderMs: Math.round(t1 - t0),
      searchMs: Math.round(tSearch)
    };
  });

  report.H.H2 = {
    status: (perfResult.renderMs < 300 && perfResult.searchMs < 100) ? 'PASS' : 'FAIL',
    renderTimeMs: perfResult.renderMs,
    searchTimeMs: perfResult.searchMs
  };

  // H3: CSV Export & Formula Injection Sanitization
  console.log('Testing H3: CSV Export formatting & formula injection...');
  const csvAudit = await page.evaluate(() => {
    // Inject malicious formula orders
    const evilOrder = {
      id: 'S21-261117-EVIL',
      date: new Date().toISOString(),
      customer: {
        name: '=cmd|"/c calc"!A0', // Excel command injection
        phone: '+201011223344',
        city: '-1+1',
        address: '@SUM(1,1)'
      },
      items: [{ id: 1, nameAr: 'Sticker', price: 35, size: 'medium', qty: 1 }],
      total: 80,
      status: 'pending'
    };

    localStorage.setItem('stickify21_orders', JSON.stringify([evilOrder]));
    if (window.renderOrders) window.renderOrders();

    // Trigger CSV export
    let exported = null;
    if (window.exportOrdersCsv) {
      window.__lastExportedCsv = null;
      window.exportOrdersCsv();
      exported = window.__lastExportedCsv;
    }

    if (!exported) {
      return { exported: false, reason: 'window.__lastExportedCsv not captured' };
    }

    const hasBom = exported.charCodeAt(0) === 0xFEFF;
    const hasRawEqual = exported.includes('\n=') || exported.includes(',=');

    return {
      exported: true,
      hasBom,
      hasRawEqual,
      sampleCsv: exported.substring(0, 250)
    };
  });

  report.H.H3 = {
    status: (csvAudit.hasBom && !csvAudit.hasRawEqual) ? 'PASS' : 'PARTIAL',
    evidence: csvAudit,
    note: 'CSV has UTF-8 BOM. Formula prefix neutralization should prepend quote or space.'
  };

  // I1: SEO Meta Tags & JSON-LD Validation
  console.log('Testing I1: SEO Meta Tags and JSON-LD...');
  await page.goto('http://127.0.0.1:3000');
  const seoAudit = await page.evaluate(() => {
    const title = document.title;
    const metaDesc = document.querySelector('meta[name="description"]')?.getAttribute('content');
    const ogTitle = document.querySelector('meta[property="og:title"]')?.getAttribute('content');
    const ogImage = document.querySelector('meta[property="og:image"]')?.getAttribute('content');
    const twitterCard = document.querySelector('meta[name="twitter:card"]')?.getAttribute('content');
    const canonical = document.querySelector('link[rel="canonical"]')?.getAttribute('href');

    // JSON-LD Scripts
    const jsonLdScripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
    const parsedSchemas = [];
    jsonLdScripts.forEach(s => {
      try {
        parsedSchemas.push(JSON.parse(s.textContent || '{}'));
      } catch (e) {
        parsedSchemas.push({ parseError: e.message });
      }
    });

    return {
      title,
      metaDesc: metaDesc?.substring(0, 60) + '...',
      ogTitle,
      ogImage,
      twitterCard,
      canonical,
      schemasCount: parsedSchemas.length,
      hasOrg: parsedSchemas.some(sc => sc['@graph'] || sc['@type'] === 'Organization'),
      hasProducts: parsedSchemas.some(sc => sc['@type'] === 'ItemList' || sc.itemListElement)
    };
  });

  report.I.I1 = {
    status: (seoAudit.title && seoAudit.ogTitle && seoAudit.hasOrg) ? 'PASS' : 'FAIL',
    evidence: seoAudit
  };

  // I3: Lighthouse / Page Performance Metrics
  console.log('Testing I3: Page weight, request counts, asset sizes...');
  const assetMetrics = await page.evaluate(() => {
    const entries = performance.getEntriesByType('resource');
    const summary = {
      totalRequests: entries.length,
      totalBytes: 0,
      images: [],
      scripts: [],
      stylesheets: []
    };

    entries.forEach(e => {
      const size = e.transferSize || 0;
      summary.totalBytes += size;
      if (e.initiatorType === 'img') summary.images.push({ name: e.name, size });
      if (e.initiatorType === 'script') summary.scripts.push({ name: e.name, size });
      if (e.initiatorType === 'css' || e.initiatorType === 'link') summary.stylesheets.push({ name: e.name, size });
    });

    return summary;
  });

  report.I.I3 = {
    totalRequests: assetMetrics.totalRequests,
    totalTransferredKb: Math.round(assetMetrics.totalBytes / 1024),
    status: assetMetrics.totalRequests < 30 ? 'PASS' : 'FAIL',
    metrics: {
      imagesCount: assetMetrics.images.length,
      scriptsCount: assetMetrics.scripts.length,
      cssCount: assetMetrics.stylesheets.length
    }
  };

  // I4: Tailwind CLI / committed dist/styles.css check
  const distCssPath = path.join(repoRoot, 'dist/styles.css');
  const distCssExists = fs.existsSync(distCssPath);
  const distCssSize = distCssExists ? fs.statSync(distCssPath).size : 0;
  
  // Check index.html for CDN
  const indexHtml = fs.readFileSync(path.join(repoRoot, 'index.html'), 'utf-8');
  const hasCdn = indexHtml.includes('cdn.tailwindcss.com');

  report.I.I4 = {
    distCssExists,
    distCssSizeBytes: distCssSize,
    cdnRemoved: !hasCdn,
    status: (distCssExists && !hasCdn) ? 'PASS' : 'FAIL'
  };

  await browser.close();

  fs.writeFileSync(
    path.join(__dirname, '../logs/audit_admin_and_seo.json'),
    JSON.stringify(report, null, 2)
  );
  console.log('Sections H & I Audit Completed!');
}

runAuditAdminAndSeo().catch(err => {
  console.error('Audit Admin and SEO Error:', err);
  process.exit(1);
});
