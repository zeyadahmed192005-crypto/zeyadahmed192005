import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, '../../');
const workCopyDir = path.resolve(__dirname, '../work-copy/mutation-test');

function copyDir(src, dest) {
  if (fs.existsSync(dest)) fs.rmSync(dest, { recursive: true, force: true });
  fs.mkdirSync(dest, { recursive: true });
  
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    if (['node_modules', '.git', 'audit', 'test-results'].includes(entry.name)) continue;
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

async function runMutations() {
  console.log('=== STARTING ISOLATED MUTATION TESTING ON PORT 3009 ===');
  copyDir(repoRoot, workCopyDir);

  // Symlink node_modules
  const nmSrc = path.join(repoRoot, 'node_modules');
  const nmDest = path.join(workCopyDir, 'node_modules');
  if (!fs.existsSync(nmDest) && fs.existsSync(nmSrc)) {
    try {
      execSync(`cmd /c mklink /J "${nmDest}" "${nmSrc}"`);
    } catch (e) {}
  }

  // Configure work copy playwright to run on port 3009 (independent from main 3000)
  const pwCfgPath = path.join(workCopyDir, 'playwright.config.js');
  let pwCfg = fs.readFileSync(pwCfgPath, 'utf-8');
  pwCfg = pwCfg.replace(/3000/g, '3009');
  pwCfg = pwCfg.replace('reuseExistingServer: true', 'reuseExistingServer: false');
  fs.writeFileSync(pwCfgPath, pwCfg, 'utf-8');

  const mutations = [
    {
      id: 'MUT-01',
      name: 'Disable XSS escapeHtml sanitization',
      file: 'src/utils/escape.js',
      originalStr: 'const s = String(str);',
      mutatedStr: 'return String(str); // MUTATION: raw unescaped HTML\n  const s = String(str);',
      testCmd: 'npx playwright test tests/phase1.spec.js -g "6. XSS attacks"',
      expectedFail: true
    },
    {
      id: 'MUT-02',
      name: 'Break Phone Validation to accept blank/any',
      file: 'src/domain/validation.js',
      originalStr: 'export function validateEgyptianPhone(phone) {',
      mutatedStr: 'export function validateEgyptianPhone(phone) { return { valid: true, value: phone }; // MUTATION: accept any phone',
      testCmd: 'npx playwright test tests/phase2.spec.js -g "2. Checkout without phone"',
      expectedFail: true
    },
    {
      id: 'MUT-03',
      name: 'Bypass Admin Lockout logic',
      file: 'src/domain/auth.js',
      originalStr: 'if (state.lockedUntil && state.lockedUntil > now) {',
      mutatedStr: 'if (false) { // MUTATION: lockout bypassed',
      testCmd: 'npx playwright test tests/phase2.spec.js -g "5. 5 wrong admin pins locks out"',
      expectedFail: true
    },
    {
      id: 'MUT-04',
      name: 'Break Pack Discount calculation',
      file: 'src/domain/pricing.js',
      originalStr: 'const discountRate = packConfig.discountRate;',
      mutatedStr: 'const discountRate = 0.0; // MUTATION: no pack discount',
      testCmd: 'npx playwright test tests/phase1.spec.js -g "3. Pack is ONE cart line"',
      expectedFail: true
    },
    {
      id: 'MUT-05',
      name: 'Allow Illegal Status Transition (pending -> shipped)',
      file: 'src/config/config.js',
      originalStr: "pending: ['awaiting_confirmation', 'confirmed', 'cancelled'],",
      mutatedStr: "pending: ['awaiting_confirmation', 'confirmed', 'shipped', 'cancelled'], // MUTATION: illegal jump",
      testCmd: 'npx playwright test tests/phase2.spec.js -g "4. Status transition pending -> shipped"',
      expectedFail: true
    }
  ];

  const mutationResults = [];

  for (const m of mutations) {
    console.log(`\nTesting ${m.id}: ${m.name}...`);
    const targetFile = path.join(workCopyDir, m.file);
    const content = fs.readFileSync(targetFile, 'utf-8');

    if (!content.includes(m.originalStr)) {
      console.warn(`Warning: Original string not found for ${m.id}! Checking alternatives...`);
      mutationResults.push({ id: m.id, name: m.name, status: 'SKIPPED_PATTERN_MISMATCH' });
      continue;
    }

    // Apply mutation
    const mutatedContent = content.replace(m.originalStr, m.mutatedStr);
    fs.writeFileSync(targetFile, mutatedContent, 'utf-8');

    // Run test against mutated work copy
    let testOutput = '';
    let testPassed = false;
    try {
      testOutput = execSync(m.testCmd, { cwd: workCopyDir, encoding: 'utf-8', timeout: 35000 });
      testPassed = true; // test passed despite mutation = TEST IS WEAK!
    } catch (err) {
      testOutput = err.stdout || err.message;
      testPassed = false; // test failed as expected!
    }

    // Revert mutation in work copy
    fs.writeFileSync(targetFile, content, 'utf-8');

    const confirmedKilled = !testPassed; // killed mutation means test caught it!
    console.log(`${m.id} Outcome: ${confirmedKilled ? 'KILLED (Test went red as expected ✓)' : 'SURVIVED (Test stayed green ✕)'}`);

    mutationResults.push({
      id: m.id,
      name: m.name,
      file: m.file,
      confirmedKilled,
      status: confirmedKilled ? 'PASS (MUTATION KILLED)' : 'FAIL (MUTATION SURVIVED)',
      outputSnippet: String(testOutput).substring(0, 200)
    });
  }

  fs.writeFileSync(
    path.join(__dirname, '../logs/mutation_testing_results.json'),
    JSON.stringify(mutationResults, null, 2)
  );
  console.log('\nMutation Testing Completed Successfully!');
}

runMutations().catch(err => {
  console.error('Mutation Test Error:', err);
  process.exit(1);
});
