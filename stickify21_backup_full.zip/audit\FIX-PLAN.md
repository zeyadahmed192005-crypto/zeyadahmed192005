# STICKIFY 21 — Prioritized Fix Plan

This document outlines the remediation roadmap for findings identified during the Independent Verification & Acceptance Audit. **No fixes are implemented in this audit run**; all items are prioritized with estimated effort and architectural dependencies for owner review and approval.

---

## 1. High Priority (Data Safety & Core Correctness)

### FIX-01: Protect Legacy Unversioned Data from Being Overwritten
- **Severity:** High (Data Loss Bug)
- **Checklist Item:** A2 / D4
- **File:** `src/data/localAdapter.js:163-176`
- **Problem:** When an existing user opens the upgraded app with their original unversioned `stickify21_*` localStorage, `localStorage.getItem('stickify21_schema_version')` is `null`. The `init()` method treats any missing version key as a fresh install and executes `safeSave(STORAGE_KEYS.PRODUCTS, SEED_PRODUCTS)`, destroying preexisting products, custom categories, and orders.
- **Remediation:** In `LocalAdapter.init()`, check if `localStorage.getItem(STORAGE_KEYS.PRODUCTS)` or `STORAGE_KEYS.ORDERS` exists before seeding. If unversioned data exists, treat `existingVersion` as `'0.0.0'` and execute `migrateStorageBundle()` rather than wiping with seed data.
- **Effort:** 30 minutes.
- **Dependencies:** None.

### FIX-02: Eliminate Order ID Collisions
- **Severity:** Medium
- **Checklist Item:** E4
- **File:** `src/utils/ids.js:22-30`
- **Problem:** Suffix uses only 2 random bytes (`new Uint8Array(2)`), producing 4 hex characters ($16^4 = 65,536$ combinations). Generating 10,000 IDs yielded 707 collisions (~7.1% collision rate) due to Birthday Paradox limits.
- **Remediation:** Increase suffix entropy to 4 bytes (8 hex characters) or use 5–6 alphanumeric characters (`[A-Z0-9]`), raising combination space from 65K to > 1 billion.
- **Effort:** 20 minutes.
- **Dependencies:** Update regex assertions in tests if length changes.

---

## 2. Medium Priority (Security, Export Safety & Tablet Layout)

### FIX-03: Neutralize CSV Formula Injection (CWE-1236)
- **Severity:** Medium (Security)
- **Checklist Item:** H3
- **File:** `admin.js:521-525`
- **Problem:** `formatCsvCell` wraps cell contents in double quotes `"${clean}"` without prefix neutralization. Cells starting with `=`, `+`, `-`, or `@` execute as formulas or DDE commands when opened in Microsoft Excel on Windows.
- **Remediation:** If `String(clean)` starts with any of `['=', '+', '-', '@']`, prepend a single quote `'` or space to force Excel to treat the cell as inert text.
- **Effort:** 25 minutes.
- **Dependencies:** None.

### FIX-04: Fix Tablet (768px) Horizontal Layout Overflow
- **Severity:** Medium (Responsive UX)
- **Checklist Item:** G2
- **File:** `index.html` (Mockup Studio / Pack Builder sections)
- **Problem:** At viewport width 768px (iPad / tablet portrait), `document.documentElement.scrollWidth` is 936px vs `clientWidth` of 768px, causing a 168px horizontal scrollbar.
- **Remediation:** Add `max-w-full overflow-hidden` and adjust grid column breakpoints (`sm:`, `md:`, `lg:`) on `#mockup-studio-section` and device canvas wrapper.
- **Effort:** 45 minutes.
- **Dependencies:** Verify with Playwright screenshot tests across all 6 viewports.

---

## 3. Low Priority (IP Compliance, Touch Ergonomics & Code Cleanliness)

### FIX-05: Remove Third-Party Protected Trademarks & Character Names
- **Severity:** Low (IP & Trademark Compliance)
- **Checklist Item:** G9
- **Files:** `index.html:354, 360, 392`
- **Problem:**
  - `لابتوب (MacBook)` references trademarked Apple MacBook.
  - `موبايل (iPhone)` references trademarked Apple iPhone.
  - `بوك مارك كلثوم` and SVG `<text>أم كلثوم</text>` references Om Kalthoum.
- **Remediation:**
  - Rename to `لابتوب (Laptop)` and `موبايل (Smartphone)`.
  - Replace the Om Kalthoum graphic with an original typographic bookmark (e.g. `بوك مارك اقتباس`).
- **Effort:** 30 minutes.
- **Dependencies:** None.

### FIX-06: Decompose Monolithic Files (`app.js` and `admin.js`)
- **Severity:** Low (Maintainability)
- **Checklist Item:** J3
- **Files:** `app.js` (2,652 lines), `admin.js` (1,729 lines)
- **Problem:** Exceeds the 500-line clean architecture maintainability standard.
- **Remediation:** Extract distinct UI controllers:
  - `src/ui/mockupController.js` (Mockup dragging & canvas rendering)
  - `src/ui/packController.js` (Pack builder logic)
  - `src/ui/customPrintController.js` (Custom print studio)
  - `src/admin/ordersController.js`, `src/admin/catalogController.js`
- **Effort:** 3–4 hours.
- **Dependencies:** FIX-01 and FIX-03 should land first.

### FIX-07: Route Direct Storage Calls Through `StorageService`
- **Severity:** Low (Architectural Consistency)
- **Checklist Item:** D1
- **Files:** `app.js:36, 542, 543, 549`, `src/domain/pricing.js:129`
- **Problem:** Cart persistence (`stickify21_cart`) and conversion tracking (`stickify21_cart_creations`) directly invoke `localStorage` instead of using the async `StorageService` interface.
- **Remediation:** Add `getCart()`, `saveCart()`, `getSettingsSync()` methods to `StorageService` / `LocalAdapter`.
- **Effort:** 45 minutes.
- **Dependencies:** None.

### FIX-08: Increase Touch Target Sizes for Mobile Buttons (< 44px)
- **Severity:** Low (WCAG Accessibility)
- **Checklist Item:** G2
- **Files:** `index.html`, `dist/styles.css`
- **Problem:** 79 interactive elements (e.g., `.finish-filter-btn`, `.cat-filter-btn`) have heights of 24px–32px, below the recommended 44px touch target guideline.
- **Remediation:** Add padding or minimum height classes (`min-h-[44px]`, `py-2.5`).
- **Effort:** 45 minutes.
- **Dependencies:** None.

### FIX-09: Update Playwright Dependencies to Resolve npm audit Advisories
- **Severity:** Low (Dev Dependency Security)
- **Checklist Item:** J4
- **File:** `package.json`
- **Problem:** `@playwright/test@1.42.1` flags 2 high-severity vulnerabilities (GHSA-7mvr-c777-76hp) regarding unverified browser download certificates.
- **Remediation:** Run `npm audit fix` or upgrade `@playwright/test` to `>=1.55.1`.
- **Effort:** 15 minutes.
- **Dependencies:** Re-verify Playwright test suite after upgrade.

---

## 4. Remediation Schedule & Effort Summary

| Item | Priority | Estimated Effort | Impact |
| :--- | :--- | :--- | :--- |
| **FIX-01** (Legacy Data Protection) | High | 30 mins | Prevents data loss for existing store installations |
| **FIX-02** (Order ID Entropy) | Medium | 20 mins | Eliminates ID collisions over 10K orders |
| **FIX-03** (CSV Formula Injection) | Medium | 25 mins | Prevents Excel DDE code injection |
| **FIX-04** (Tablet 768px Scrollbar) | Medium | 45 mins | Eliminates layout overflow on iPads/tablets |
| **FIX-05** (Trademark & IP Removal) | Low | 30 mins | 100% compliance with IP guidelines |
| **FIX-06** (Decompose Monolithic Files)| Low | 3–4 hrs | Clean code architecture & readability |
| **FIX-07** (Storage Layer Bypasses) | Low | 45 mins | 100% data abstraction |
| **FIX-08** (Mobile Tap Targets >= 44px)| Low | 45 mins | WCAG accessibility compliance |
| **FIX-09** (npm audit Update) | Low | 15 mins | Zero security advisories |
| **Total Estimated Effort** | — | **~7 hours** | — |
