// @ts-check
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  timeout: 30090,
  fullyParallel: false,
  workers: 1,
  reporter: 'list',
  use: {
    baseURL: 'http://127.0.0.1:3009',
    channel: 'msedge'
  },
  webServer: {
    command: 'python scripts/server.py 3009',
    url: 'http://127.0.0.1:3009',
    reuseExistingServer: false,
    timeout: 15000
  }
});
