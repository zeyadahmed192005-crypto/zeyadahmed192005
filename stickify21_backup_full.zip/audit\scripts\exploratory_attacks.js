import { chromium } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function runExploratoryAttacks() {
  console.log('=== STARTING EXPLORATORY ATTACKS ===');
  const report = {};
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  const page = await browser.newPage();

  // Attack 1: Emoji & Zero-Width characters in customer name
  console.log('Attack 1: Emoji & Zero-width in customer name...');
  const { validateCustomerName } = await import('../../src/domain/validation.js');
  const emojiName = validateCustomerName('أحمد محمد 🌸');
  const zwjName = validateCustomerName('محمود\u200Cعلي'); // zero width non-joiner
  const longName = validateCustomerName('أ'.repeat(500)); // 500 chars

  report.attack1_name_edge_cases = {
    emojiRejected: !emojiName.valid,
    emojiError: emojiName.error,
    zwjRejected: !zwjName.valid,
    zwjError: zwjName.error,
    longNameValid: longName.valid, // Is there a max length guard?
    longNameLength: 500,
    finding: emojiName.valid ? 'Allowed' : 'Emoji in Egyptian customer names (very common in youth/social orders) is strictly rejected with "الاسم يحتوي على رموز غير مسموح بها". Also no max-length limit on name (500 chars allowed).'
  };

  // Attack 2: Pasting Giant Malformed JSON into WhatsApp import
  console.log('Attack 2: Pasting Giant Malformed String into WhatsApp import...');
  const { parseOrderCode } = await import('../../src/utils/ids.js');
  const giantString = 'S21CODE:' + 'A'.repeat(500000); // 500KB string
  let giantStringHandled = false;
  let giantError = '';
  try {
    parseOrderCode(giantString);
  } catch (err) {
    giantStringHandled = true;
    giantError = err.message;
  }

  report.attack2_giant_import = {
    handledGracefully: giantStringHandled,
    errorThrown: giantError
  };

  // Attack 3: Cart with 500 lines & calculation performance
  console.log('Attack 3: Stress-testing cart with 500 items...');
  const { calculateCart } = await import('../../src/domain/pricing.js');
  const bigCart = [];
  for (let i = 1; i <= 500; i++) {
    bigCart.push({
      id: i,
      nameAr: `استيكر رقم ${i}`,
      size: i % 3 === 0 ? 'large' : (i % 2 === 0 ? 'medium' : 'small'),
      price: i % 3 === 0 ? 50 : (i % 2 === 0 ? 35 : 25),
      quantity: 1
    });
  }

  const t0 = performance.now();
  const bigCartResult = calculateCart(bigCart, null, 'القاهرة');
  const t1 = performance.now();

  report.attack3_cart_stress = {
    itemCount: 500,
    calcDurationMs: Math.round((t1 - t0) * 100) / 100,
    subtotal: bigCartResult.subtotal,
    isFreeShipping: bigCartResult.isFreeShipping,
    total: bigCartResult.total,
    performanceAcceptable: (t1 - t0) < 50
  };

  // Attack 4: Clearing Storage mid-session on Storefront
  console.log('Attack 4: Clearing storage mid-session in browser...');
  await page.goto('http://127.0.0.1:3000');
  await page.waitForSelector('.sticker-card');
  
  // Add item to cart
  await page.locator('.sticker-card button:has-text("أضف للسلة")').first().click();
  await page.click('#cart-btn');
  await page.waitForSelector('#cart-modal:not(.hidden)');

  // Clear storage while cart modal is open
  await page.evaluate(() => localStorage.clear());

  // Click checkout
  let crashedOnClear = false;
  try {
    await page.click('button:has-text("إتمام الشراء بالبيانات التفصيلية")');
    await page.waitForTimeout(500);
  } catch (e) {
    crashedOnClear = true;
  }

  const checkoutModalOpen = await page.isVisible('#checkout-modal');
  report.attack4_clear_storage_mid_session = {
    crashed: crashedOnClear,
    checkoutModalOpen,
    resilient: !crashedOnClear
  };

  // Attack 5: System Language / RTL Mixing & Overflow
  console.log('Attack 5: Extreme RTL/LTR mixed text in search & notes...');
  const mixedText = 'ENGLISH text mixed مع لغة عربية و رموز 🚀 123 !@# and very long word without spaces: ' + 'A'.repeat(80);
  await page.goto('http://127.0.0.1:3000');
  await page.fill('#search-input', mixedText);
  await page.waitForTimeout(200);

  const searchBoxOverflow = await page.evaluate(() => {
    const input = document.getElementById('search-input');
    return input ? input.value.length : 0;
  });

  report.attack5_mixed_rtl_ltr = {
    textLength: searchBoxOverflow,
    displayed: searchBoxOverflow > 0
  };

  await browser.close();

  fs.writeFileSync(
    path.join(__dirname, '../logs/exploratory_attacks_results.json'),
    JSON.stringify(report, null, 2)
  );
  console.log('Exploratory Attacks Completed!');
}

runExploratoryAttacks().catch(err => {
  console.error('Exploratory Attack Error:', err);
  process.exit(1);
});
