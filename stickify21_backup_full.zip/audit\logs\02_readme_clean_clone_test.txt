=== TESTING README INSTRUCTIONS IN CLEAN CLONE ===
Step 1: npm install
npm WARN deprecated @playwright/test@1.42.1: Please update to the latest version of Playwright to test up-to-date browsers.

added 142 packages, and audited 143 packages in 17s

39 packages are looking for funding
  run `npm fund` for details

2 high severity vulnerabilities

To address all issues, run:
  npm audit fix

Run `npm audit` for details.
Step 2: npm run build:css

> stickify21@1.0.0 build:css
> tailwindcss -i ./styles.css -o ./dist/styles.css --minify

Browserslist: caniuse-lite is outdated. Please run:
  npx update-browserslist-db@latest
  Why you should do it regularly: https://github.com/browserslist/update-db#readme
System.Management.Automation.RemoteException
Rebuilding...
System.Management.Automation.RemoteException
Done in 1889ms.
Step 3: python scripts/server.py 3005 test (run 2s and check)
Server Response Status: 200
