import { chromium } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const origDir = 'C:\\Users\\zeyad\\.gemini\\antigravity\\scratch\\stickify21-original-backup';
const currDir = 'C:\\Users\\zeyad\\.gemini\\antigravity\\scratch\\stickify21';

async function auditSectionA() {
  const results = { section: 'A', items: {} };

  // A1: Diff original vs current
  const origFiles = fs.readdirSync(origDir);
  const currFiles = fs.readdirSync(currDir);
  const diffReport = [];

  for (const f of origFiles) {
    if (f === '.git') continue;
    const exists = fs.existsSync(path.join(currDir, f));
    diffReport.push({ file: f, status: exists ? 'Preserved' : 'Missing' });
  }

  // Check new files vs original
  const newFiles = currFiles.filter(f => !origFiles.includes(f) && f !== '.git' && f !== 'audit');
  results.items.A1 = {
    origFiles,
    diffReport,
    newFiles,
    status: diffReport.every(d => d.status === 'Preserved') ? 'PASS' : 'FAIL'
  };

  // Launch browser for live functional checks
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // A2: Old data migration
  // Original localStorage format had no schemaVersion and stored raw products, categories, coupons, orders
  const oldSeedProducts = [
    { id: 991, sku: 'STK-OLD-01', name: 'Legacy Sticker', nameAr: 'استيكر قديم موروث', category: 'stickers', subCategory: 'tech', type: 'sticker', price: 25, finish: 'glossy', badge: 'legacy', desc: 'استيكر تجريبي لاختبار الترقية', svg: '<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" fill="#FF5000"/></svg>', dateAdded: '2025-01-01' }
  ];
  const oldSeedCategories = [
    { id: 'legacy_cat', name: 'Legacy Cat', nameAr: 'قسم قديم', icon: '📦', count: 1 }
  ];

  await page.goto('http://127.0.0.1:3000');
  // Inject raw unversioned old format
  await page.evaluate(({ prods, cats }) => {
    localStorage.clear();
    sessionStorage.clear();
    localStorage.setItem('stickify21_products', JSON.stringify(prods));
    localStorage.setItem('stickify21_categories', JSON.stringify(cats));
    localStorage.setItem('stickify21_cart', JSON.stringify([{ id: 'STK-OLD-01-small', productId: 991, size: 'small', quantity: 2 }]));
  }, { prods: oldSeedProducts, cats: oldSeedCategories });

  // Reload page to trigger migrations & storage init
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1000);

  // Check if migrated with schemaVersion
  const migrationResult = await page.evaluate(() => {
    const rawProds = localStorage.getItem('stickify21_products');
    const rawCats = localStorage.getItem('stickify21_categories');
    const rawVersion = localStorage.getItem('stickify21_schema_version');
    const parsedProds = JSON.parse(rawProds || '[]');
    const parsedCats = JSON.parse(rawCats || '[]');
    return {
      hasSchemaVersion: !!rawVersion,
      version: rawVersion,
      productFound: parsedProds.some(p => p.sku === 'STK-OLD-01'),
      categoryFound: parsedCats.some(c => c.id === 'legacy_cat')
    };
  });

  results.items.A2 = {
    status: (migrationResult.hasSchemaVersion && migrationResult.productFound && migrationResult.categoryFound) ? 'PASS' : 'FAIL',
    evidence: migrationResult
  };

  // A3: Brand identity preserved
  const brandAudit = await page.evaluate(() => {
    const computedHtml = window.getComputedStyle(document.documentElement);
    const computedBody = window.getComputedStyle(document.body);
    const dir = document.documentElement.getAttribute('dir');
    const lang = document.documentElement.getAttribute('lang');
    const bodyFont = computedBody.fontFamily;
    
    // Check WhatsApp link
    const waLink = document.querySelector('a[href*="201043546503"]');

    return {
      dir,
      lang,
      bodyFont,
      hasWhatsApp: !!waLink,
      waHref: waLink ? waLink.getAttribute('href') : null
    };
  });

  results.items.A3 = {
    status: (brandAudit.dir === 'rtl' && brandAudit.lang === 'ar' && brandAudit.bodyFont.includes('Readex Pro') && brandAudit.hasWhatsApp) ? 'PASS' : 'FAIL',
    evidence: brandAudit
  };

  // A4: Mockup studio surfaces, pack builder 5/10, category cards, search, finish filter
  const surfaces = await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('.mockup-device-btn'));
    return btns.map(b => b.textContent.trim());
  });

  const packBuilder = await page.evaluate(() => {
    const p5 = document.querySelector('button[onclick*="5"]');
    const p10 = document.querySelector('button[onclick*="10"]');
    return { has5: !!p5, has10: !!p10 };
  });

  results.items.A4 = {
    surfaces,
    packBuilder,
    status: (surfaces.length >= 4 && packBuilder.has5 && packBuilder.has10) ? 'PASS' : 'FAIL'
  };

  await browser.close();

  fs.writeFileSync(
    path.join(__dirname, '../logs/audit_section_a.json'),
    JSON.stringify(results, null, 2)
  );
  console.log('Section A Audit Completed:', results);
}

auditSectionA().catch(err => {
  console.error('Section A Error:', err);
  process.exit(1);
});
