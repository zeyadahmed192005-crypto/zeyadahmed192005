import { chromium } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, '../../');
const screenshotsDir = path.resolve(__dirname, '../screenshots');

const VIEWPORTS = [
  { name: '360', width: 360, height: 640 },
  { name: '375', width: 375, height: 667 },
  { name: '768', width: 768, height: 1024 },
  { name: '1024', width: 1024, height: 768 },
  { name: '1280', width: 1280, height: 800 },
  { name: '1920', width: 1920, height: 1080 }
];

async function runSectionGAudit() {
  console.log('=== STARTING SECTION G AUDIT (UX, VIEWPORTS, ACCESSIBILITY) ===');
  const report = { section: 'G', items: {} };
  const browser = await chromium.launch({ channel: 'msedge', headless: true });

  const overflowReport = [];
  const tapTargetOffenders = [];

  // Capture screenshots across viewports for Home
  for (const vp of VIEWPORTS) {
    const context = await browser.newContext({
      viewport: { width: vp.width, height: vp.height },
      hasTouch: vp.width <= 768
    });
    const page = await context.newPage();
    await page.goto('http://127.0.0.1:3000', { waitUntil: 'networkidle' });

    // Check horizontal overflow
    const overflow = await page.evaluate(() => {
      const doc = document.documentElement;
      return {
        scrollWidth: doc.scrollWidth,
        clientWidth: doc.clientWidth,
        hasOverflow: doc.scrollWidth > doc.clientWidth
      };
    });

    overflowReport.push({ viewport: vp.name, overflow });

    // Screenshot Home
    const homeShot = path.join(screenshotsDir, `home_${vp.name}.png`);
    await page.screenshot({ path: homeShot, fullPage: false });

    // Category / Products
    await page.locator('#categories-section').scrollIntoViewIfNeeded();
    await page.screenshot({ path: path.join(screenshotsDir, `categories_${vp.name}.png`) });

    // Mockup Studio
    await page.locator('#mockup-studio-section').scrollIntoViewIfNeeded();
    await page.screenshot({ path: path.join(screenshotsDir, `mockup_${vp.name}.png`) });

    // Custom Order
    await page.locator('#custom-order').scrollIntoViewIfNeeded();
    await page.screenshot({ path: path.join(screenshotsDir, `custom_order_${vp.name}.png`) });

    // Cart Modal
    await page.click('#cart-btn');
    await page.waitForTimeout(300);
    await page.screenshot({ path: path.join(screenshotsDir, `cart_modal_${vp.name}.png`) });
    await page.keyboard.press('Escape');
    await page.waitForTimeout(200);

    // Tracking Modal
    await page.goto('http://127.0.0.1:3000/#/track');
    await page.waitForTimeout(300);
    await page.screenshot({ path: path.join(screenshotsDir, `tracking_${vp.name}.png`) });

    // Tap Target Scan on 375px
    if (vp.name === '375') {
      const offenders = await page.evaluate(() => {
        const clickable = Array.from(document.querySelectorAll('button, a, input, select'));
        const small = [];
        clickable.forEach(el => {
          const rect = el.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0 && (rect.width < 40 || rect.height < 40)) {
            small.push({
              tag: el.tagName,
              id: el.id || '',
              class: el.className ? String(el.className).substring(0, 40) : '',
              text: (el.textContent || '').trim().substring(0, 25),
              width: Math.round(rect.width),
              height: Math.round(rect.height)
            });
          }
        });
        return small;
      });
      tapTargetOffenders.push(...offenders);
    }

    // Admin Dashboard Screenshots (all tabs)
    await page.goto('http://127.0.0.1:3000/admin.html');
    await page.waitForTimeout(300);
    // Fill pin if lock screen
    const lock = await page.$('#admin-lock-screen:not(.hidden)');
    if (lock) {
      await page.fill('#admin-pin-input', '2121');
      await page.click('#admin-login-btn');
      await page.waitForTimeout(500);
    }

    const tabs = ['orders', 'products', 'categories', 'coupons', 'settings'];
    for (const tab of tabs) {
      const tabBtn = await page.$(`#tab-btn-${tab}`);
      if (tabBtn) {
        await tabBtn.click();
        await page.waitForTimeout(200);
        await page.screenshot({ path: path.join(screenshotsDir, `admin_${tab}_${vp.name}.png`) });
      }
    }

    await context.close();
  }

  report.items.G1 = {
    status: 'PASS',
    screenshotsCaptured: fs.readdirSync(screenshotsDir).length,
    viewportsTested: VIEWPORTS.map(v => v.name)
  };

  report.items.G2 = {
    horizontalOverflow: overflowReport,
    hasAnyOverflow: overflowReport.some(o => o.overflow.hasOverflow),
    tapTargetOffendersSample: tapTargetOffenders.slice(0, 10),
    totalTapTargetOffenders: tapTargetOffenders.length,
    status: (!overflowReport.some(o => o.overflow.hasOverflow) && tapTargetOffenders.length < 5) ? 'PASS' : 'PARTIAL'
  };

  // G3: Complete purchase at 375px using touch only
  const touchCtx = await browser.newContext({
    viewport: { width: 375, height: 667 },
    hasTouch: true,
    isMobile: true
  });
  const touchPage = await touchCtx.newPage();
  await touchPage.goto('http://127.0.0.1:3000');
  await touchPage.evaluate(() => localStorage.clear());
  await touchPage.reload();
  await touchPage.waitForSelector('.sticker-card');

  // Tap add to cart
  await touchPage.tap('.sticker-card button:has-text("أضف للسلة")');
  await touchPage.waitForTimeout(300);
  await touchPage.tap('#cart-btn');
  await touchPage.waitForSelector('#cart-modal:not(.hidden)');
  await touchPage.tap('button:has-text("إتمام الشراء بالبيانات التفصيلية")');
  await touchPage.waitForSelector('#checkout-modal:not(.hidden)');

  await touchPage.fill('#order-name', 'سارة محمود');
  await touchPage.fill('#order-phone', '01011223344');
  await touchPage.selectOption('#order-city', 'الإسكندرية');
  await touchPage.fill('#order-address', 'شارع فؤاد، محطة الرمل');

  // Submit via touch
  await touchPage.tap('#checkout-submit-btn');
  await touchPage.waitForSelector('#order-confirmation-modal:not(.hidden)');

  const orderIdText = await touchPage.textContent('#confirmed-order-id');
  const g3Success = orderIdText && orderIdText.includes('S21-');

  report.items.G3 = {
    status: g3Success ? 'PASS' : 'FAIL',
    orderIdText: orderIdText ? orderIdText.trim() : null
  };
  await touchCtx.close();

  // G8: String / Quality leak scan (Lorem, TODO, undefined, NaN, [object Object], null)
  const g8Page = await browser.newPage();
  await g8Page.goto('http://127.0.0.1:3000');
  const leakedStrings = await g8Page.evaluate(() => {
    const text = document.body.innerText;
    const targets = ['Lorem', 'TODO', 'undefined', 'NaN', '[object Object]', 'null'];
    const hits = [];
    targets.forEach(t => {
      if (text.includes(t)) hits.push(t);
    });
    return hits;
  });

  report.items.G8 = {
    leaks: leakedStrings,
    status: leakedStrings.length === 0 ? 'PASS' : 'FAIL'
  };

  // G9: Content / IP check (One Piece, Luffy, Om Kalthoum, Apple logos)
  const g9Grep = [];
  const filesForIp = ['index.html', 'app.js', 'src/data/seed.js', 'docs/DECISIONS.md'];
  const bannedKeywords = ['One Piece', 'Luffy', 'أم كلثوم', 'MacBook', 'iPhone', 'Apple'];
  for (const f of filesForIp) {
    const content = fs.readFileSync(path.join(repoRoot, f), 'utf-8');
    bannedKeywords.forEach(kw => {
      if (content.includes(kw)) {
        g9Grep.push({ file: f, keyword: kw });
      }
    });
  }

  report.items.G9 = {
    status: g9Grep.length === 0 ? 'PASS' : 'FAIL',
    violations: g9Grep
  };

  await browser.close();

  fs.writeFileSync(
    path.join(__dirname, '../logs/audit_section_g.json'),
    JSON.stringify(report, null, 2)
  );
  console.log('Section G Audit Completed!');
}

runSectionGAudit().catch(err => {
  console.error('Section G Error:', err);
  process.exit(1);
});
