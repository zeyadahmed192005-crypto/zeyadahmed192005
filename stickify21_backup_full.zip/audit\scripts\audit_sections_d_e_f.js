import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { chromium } from '@playwright/test';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, '../../');

async function runAuditDEF() {
  console.log('=== STARTING AUDIT FOR SECTIONS D, E, F ===');
  const report = { D: {}, E: {}, F: {} };

  // D1: Grep direct localStorage / sessionStorage outside data layer & auth
  console.log('Checking D1: Direct storage access outside data layer...');
  const filesToCheck = ['app.js', 'src/domain/pricing.js', 'src/domain/orders.js', 'src/domain/coupons.js'];
  const directStorageHits = [];
  for (const f of filesToCheck) {
    const full = path.join(repoRoot, f);
    if (!fs.existsSync(full)) continue;
    const lines = fs.readFileSync(full, 'utf-8').split('\n');
    lines.forEach((l, idx) => {
      if ((l.includes('localStorage.') || l.includes('sessionStorage.')) && !l.includes('//') && !l.includes('*')) {
        directStorageHits.push({ file: f, line: idx + 1, code: l.trim() });
      }
    });
  }
  report.D.D1 = {
    status: directStorageHits.length === 0 ? 'PASS' : 'PARTIAL',
    hits: directStorageHits,
    note: 'In app.js, cart_creations tracking or legacy storage fallbacks may exist.'
  };

  // E4: Generate 10,000 Order IDs and check format & collisions
  console.log('Testing E4: Generating 10,000 Order IDs...');
  const { generateOrderId } = await import('../../src/utils/ids.js');
  const idSet = new Set();
  let regexFailures = 0;
  const idRegex = /^S21-\d{6}-[A-Z0-9]{4}$/;

  for (let i = 0; i < 10000; i++) {
    const id = generateOrderId();
    if (!idRegex.test(id)) regexFailures++;
    idSet.add(id);
  }

  report.E.E4 = {
    totalGenerated: 10000,
    uniqueCount: idSet.size,
    collisions: 10000 - idSet.size,
    regexFailures,
    sample: Array.from(idSet).slice(0, 5),
    status: (idSet.size === 10000 && regexFailures === 0) ? 'PASS' : 'FAIL'
  };

  // E5: Order Status Transition Machine (N x N)
  console.log('Testing E5: Order Status Transition Matrix...');
  const { ORDER_STATUSES, isValidStatusTransition } = await import('../../src/domain/orders.js');
  const allStatuses = Object.keys(ORDER_STATUSES);
  const matrix = {};
  let totalTransitions = 0;
  let allowedTransitions = 0;

  for (const from of allStatuses) {
    matrix[from] = {};
    for (const to of allStatuses) {
      totalTransitions++;
      const valid = isValidStatusTransition(from, to);
      matrix[from][to] = valid;
      if (valid) allowedTransitions++;
    }
  }

  // Verify specific rules:
  // pending -> shipped should be false
  // awaiting_confirmation -> confirmed should be true
  // completed -> pending should be false
  const pToS = isValidStatusTransition('pending', 'shipped');
  const acToC = isValidStatusTransition('awaiting_confirmation', 'confirmed');
  const cToP = isValidStatusTransition('completed', 'pending');

  report.E.E5 = {
    totalTransitionsTested: totalTransitions,
    allowedTransitions,
    pToS_ShouldBeFalse: pToS === false,
    acToC_ShouldBeTrue: acToC === true,
    cToP_ShouldBeFalse: cToP === false,
    status: (!pToS && acToC && !cToP) ? 'PASS' : 'FAIL',
    sampleMatrix: matrix
  };

  // E6: Egyptian Mobile Validation Matrix
  console.log('Testing E6: Egyptian Phone Normalization & Validation...');
  const { validateOrderData, validateEgyptianPhone } = await import('../../src/domain/validation.js');
  
  const phoneTestCases = [
    { input: '01012345678', expectedValid: true, expectedNormalized: '01012345678' },
    { input: '+201012345678', expectedValid: true, expectedNormalized: '01012345678' },
    { input: '00201012345678', expectedValid: true, expectedNormalized: '01012345678' },
    { input: '201012345678', expectedValid: true, expectedNormalized: '01012345678' },
    { input: '01198765432', expectedValid: true, expectedNormalized: '01198765432' },
    { input: '01234567890', expectedValid: true, expectedNormalized: '01234567890' },
    { input: '01511223344', expectedValid: true, expectedNormalized: '01511223344' },
    { input: '٠١٠١٢٣٤٥٦٧٨', expectedValid: true, expectedNormalized: '01012345678' }, // Arabic-Indic digits
    { input: '010 1234 5678', expectedValid: true, expectedNormalized: '01012345678' }, // with spaces
    { input: '010-1234-5678', expectedValid: true, expectedNormalized: '01012345678' }, // with dashes
    { input: '01312345678', expectedValid: false }, // 013 is landline Qalyubia, not mobile
    { input: '0101234567', expectedValid: false }, // 10 digits only
    { input: '010123456789', expectedValid: false }, // 12 digits
    { input: '0223456789', expectedValid: false }, // Cairo landline
    { input: 'abcdefghijk', expectedValid: false }
  ];

  const phoneResults = [];
  for (const tc of phoneTestCases) {
    const res = validateEgyptianPhone(tc.input);
    const valid = res.valid;
    const norm = res.value || null;
    const passed = (valid === tc.expectedValid) && (!valid || (tc.expectedNormalized ? norm === tc.expectedNormalized : true));
    phoneResults.push({
      input: tc.input,
      normalized: norm,
      valid,
      expectedValid: tc.expectedValid,
      passed
    });
  }

  report.E.E6 = {
    totalPhoneTests: phoneTestCases.length,
    passedCount: phoneResults.filter(p => p.passed).length,
    status: phoneResults.every(p => p.passed) ? 'PASS' : 'FAIL',
    details: phoneResults
  };

  // F1: Table-Driven Test of calculateCart (>= 30 cases)
  console.log('Testing F1: 30+ Independent Table-Driven Pricing Tests...');
  const { calculateCart } = await import('../../src/domain/pricing.js');

  // Independent reference calculator
  function independentCalc(items, coupon, gov, customShippingRates = {}) {
    let subtotal = 0;
    items.forEach(it => {
      if (it.type === 'pack') {
        // 5 pack 20%, 10 pack 30%
        const count = it.itemCount || 5;
        const discountRate = count >= 10 ? 0.30 : 0.20;
        let baseUnitPrice = 35; // medium default
        if (it.size === 'small') baseUnitPrice = 25;
        if (it.size === 'large') baseUnitPrice = 50;
        const rawTotal = count * baseUnitPrice;
        const packPrice = Math.round(rawTotal * (1 - discountRate));
        subtotal += packPrice * (it.quantity || 1);
      } else {
        let price = it.price || 35;
        if (it.size === 'small') price = 25;
        if (it.size === 'large') price = 50;
        subtotal += price * (it.quantity || 1);
      }
    });

    let discount = 0;
    if (coupon && coupon.active !== false) {
      if (coupon.type === 'percentage') {
        discount = Math.round((subtotal * coupon.value) / 100);
      } else if (coupon.type === 'fixed') {
        discount = Math.min(coupon.value, subtotal);
      }
    }

    const discountedSubtotal = Math.max(0, subtotal - discount);
    
    // Free shipping threshold after discount: 200 EGP
    const isFreeShipping = discountedSubtotal >= 200;
    let shippingFee = 0;
    if (!isFreeShipping) {
      shippingFee = customShippingRates[gov] !== undefined ? customShippingRates[gov] : 45;
    }

    const total = discountedSubtotal + shippingFee;
    return { subtotal, discount, discountedSubtotal, shippingFee, isFreeShipping, total };
  }

  const f1Cases = [];
  const testGovs = ['القاهرة', 'الجيزة', 'الإسكندرية', 'أسيوط', 'أسوان'];
  const testCoupons = [
    null,
    { code: 'STICKIFY10', type: 'percentage', value: 10, minSubtotal: 100 },
    { code: 'FLAT20', type: 'fixed', value: 20, minSubtotal: 50 },
    { code: 'INVALID', active: false }
  ];

  let caseId = 1;
  let mismatches = 0;

  for (let q = 1; q <= 3; q++) {
    for (const gov of testGovs) {
      for (const coup of testCoupons) {
        const items = [
          { productId: 1, type: 'sticker', size: 'medium', price: 35, quantity: q },
          { productId: 2, type: 'sticker', size: 'large', price: 50, quantity: 1 }
        ];
        
        // Add a pack in some cases
        if (caseId % 2 === 0) {
          items.push({ type: 'pack', size: 'medium', itemCount: 5, quantity: 1 });
        }

        const expected = independentCalc(items, coup, gov);
        const actual = calculateCart(items, coup, gov);

        const match = (expected.subtotal === actual.subtotal) &&
                      (expected.discount === actual.discount) &&
                      (expected.shippingFee === actual.shippingFee) &&
                      (expected.total === actual.total);

        if (!match) mismatches++;

        f1Cases.push({
          caseId,
          itemCount: items.length,
          gov,
          couponCode: coup ? coup.code : 'NONE',
          expected,
          actual: {
            subtotal: actual.subtotal,
            discount: actual.discount,
            shippingFee: actual.shippingFee,
            total: actual.total
          },
          match
        });
        caseId++;
      }
    }
  }

  report.F.F1 = {
    totalCasesTested: f1Cases.length,
    mismatches,
    status: mismatches === 0 ? 'PASS' : 'FAIL',
    sampleCases: f1Cases.slice(0, 5)
  };

  // E7: Order Code Base64url encode / decode integrity
  console.log('Testing E7: Order Code Base64url round-trip...');
  const { generateOrderCode, parseOrderCode } = await import('../../src/utils/ids.js');
  const sampleOrder = {
    id: 'S21-261117-TEST',
    customer: {
      name: 'عميل تجريبي',
      phone: '01012345678',
      city: 'القاهرة',
      address: 'شارع التحرير، الدقي',
      notes: 'برجاء الاتصال قبل التوصيل'
    },
    total: 245,
    subtotal: 200,
    shippingCost: 45,
    items: [{ id: 1, nameAr: 'استيكر تجربة', size: 'medium', qty: 2, price: 35 }]
  };

  const code = generateOrderCode(sampleOrder);
  let decoded = null;
  try {
    decoded = parseOrderCode(code);
  } catch (e) {}

  const e7Pass = decoded && decoded.id === sampleOrder.id && decoded.customer.phone === sampleOrder.customer.phone;

  // Tampered code test
  const tamperedCode = code.slice(0, -5) + 'XXXXX';
  let decodedTampered = null;
  let tamperedCaught = false;
  try {
    decodedTampered = parseOrderCode(tamperedCode);
  } catch (e) {
    tamperedCaught = true;
  }

  report.E.E7 = {
    encodedCode: code.substring(0, 40) + '...',
    roundTripSuccess: e7Pass,
    tamperedRejected: tamperedCaught,
    status: (e7Pass && tamperedCaught) ? 'PASS' : 'FAIL'
  };

  // F2: Coupon Edge Cases
  console.log('Testing F2: Coupon Edge Cases...');
  const { evaluateCoupon } = await import('../../src/domain/coupons.js');
  const availableCoupons = [
    { code: 'STICKIFY10', type: 'percentage', value: 10, minSubtotal: 100, active: true },
    { code: 'EXPIRED', type: 'percentage', value: 20, expiryDate: '2020-01-01', active: true },
    { code: 'EXHAUSTED', type: 'fixed', value: 50, usageLimit: 1, usageCount: 1, active: true },
    { code: 'INACTIVE', type: 'percentage', value: 15, active: false }
  ];

  const couponTests = [
    { code: 'STICKIFY10', subtotal: 150, expectedValid: true },
    { code: 'STICKIFY10', subtotal: 50, expectedValid: false, reason: 'minSubtotal' },
    { code: 'EXPIRED', subtotal: 200, expectedValid: false },
    { code: 'EXHAUSTED', subtotal: 200, expectedValid: false },
    { code: 'INACTIVE', subtotal: 200, expectedValid: false },
    { code: 'stickify10', subtotal: 150, expectedValid: true }, // case insensitive
    { code: ' STICKIFY10 ', subtotal: 150, expectedValid: true }, // whitespace trimmed
    { code: 'NONEXISTENT', subtotal: 500, expectedValid: false }
  ];

  const couponResults = [];
  for (const ct of couponTests) {
    const res = evaluateCoupon(ct.code, availableCoupons, { subtotal: ct.subtotal });
    const pass = res.valid === ct.expectedValid;
    couponResults.push({ code: ct.code, subtotal: ct.subtotal, valid: res.valid, pass, error: res.error });
  }

  report.F.F2 = {
    totalCouponTests: couponTests.length,
    status: couponResults.every(c => c.pass) ? 'PASS' : 'FAIL',
    details: couponResults
  };

  fs.writeFileSync(
    path.join(__dirname, '../logs/audit_sections_d_e_f.json'),
    JSON.stringify(report, null, 2)
  );
  console.log('Sections D, E, F Audit Completed!');
}

runAuditDEF().catch(err => {
  console.error('Audit DEF Error:', err);
  process.exit(1);
});
