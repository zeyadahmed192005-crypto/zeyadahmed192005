import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, '../../');

async function runTestSuite3x() {
  console.log('=== RUNNING FULL PLAYWRIGHT SUITE 3 CONSECUTIVE TIMES ===');
  const runs = [];

  for (let i = 1; i <= 3; i++) {
    console.log(`\n--- RUN #${i} ---`);
    const t0 = Date.now();
    let passed = false;
    let output = '';
    try {
      output = execSync('npx playwright test', { cwd: repoRoot, encoding: 'utf-8', timeout: 180000 });
      passed = true;
    } catch (err) {
      output = err.stdout || err.message;
      passed = false;
    }
    const t1 = Date.now();
    const durationSec = ((t1 - t0) / 1000).toFixed(1);

    const match = output.match(/(\d+) passed/);
    const passedCount = match ? parseInt(match[1], 10) : 0;
    const failMatch = output.match(/(\d+) failed/);
    const failedCount = failMatch ? parseInt(failMatch[1], 10) : 0;

    console.log(`Run #${i}: ${passed ? 'ALL PASSED' : 'SOME FAILED'} in ${durationSec}s (${passedCount} passed, ${failedCount} failed)`);
    runs.push({
      runNumber: i,
      passed,
      passedCount,
      failedCount,
      durationSec: Number(durationSec),
      outputSnippet: output.split('\n').filter(l => l.includes('passed') || l.includes('failed') || l.includes('Slow test')).join('\n')
    });
  }

  const allPassed = runs.every(r => r.passed && r.passedCount === 34);
  const avgDuration = (runs.reduce((sum, r) => sum + r.durationSec, 0) / 3).toFixed(1);

  const summary = {
    totalRuns: 3,
    allPassed,
    isFlaky: !allPassed,
    averageDurationSec: Number(avgDuration),
    runs
  };

  fs.writeFileSync(
    path.join(__dirname, '../logs/test_suite_3x_runs.json'),
    JSON.stringify(summary, null, 2)
  );
  console.log('\n3x Test Suite Runs Completed!');
}

runTestSuite3x().catch(err => {
  console.error('Error in 3x runs:', err);
  process.exit(1);
});
