import { chromium } from '@playwright/test';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function run() {
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  const filePath = path.resolve(__dirname, '../../index.html');
  const fileUrl = `file://${filePath.replace(/\\/g, '/')}`;

  console.log(`Navigating to: ${fileUrl}`);
  await page.goto(fileUrl);

  const banner = await page.$('#file-protocol-warning');
  if (banner) {
    const text = await banner.textContent();
    console.log(`PASS: #file-protocol-warning found. Text: "${text.trim()}"`);
    await page.screenshot({ path: path.resolve(__dirname, '../screenshots/file_protocol_warning.png') });
  } else {
    console.log('FAIL: #file-protocol-warning NOT found.');
  }

  await browser.close();
}

run().catch(err => {
  console.error('ERROR:', err);
  process.exit(1);
});
